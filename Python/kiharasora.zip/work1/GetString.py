#!/usr/bin/python3

import json

class GetString:
    def __init__(self, json_key):
        '''
        このクラスで扱うインスタンスが持つ変数を宣言する

        '''
        self.key = json_key
        self.string = ''

    def json_string(self):
        '''
        jsonファイルからバリューを取得し、文字列として保持しTrueを送信する
        バリューが取得できなかった場合、エラー文字列を保持しFalseを送信する
        
        '''
        try:
            with open('template_strings.json') as template_json:
                template_dict = json.load(template_json)
                self.string = template_dict[self.key]
            return True

        except FileNotFoundError: #ファイルが見つからなかった時のエラー処理
            self.string = 'jsonファイルが存在しません。プログラムを終了します。'
            return False
        
        except KeyError: #jsonキーが見つからなかった時のエラー処理
            self.string = 'キーが存在しません。プログラムを終了します'
            return False
        
        except: #jsonファイルが壊れていた時のエラー処理
            self.string = 'jsonファイルが壊れています。プログラムを終了します。'
            return False
