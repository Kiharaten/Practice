#!/usr/bin/python3

from xbee import ZigBee
import serial
import time
import pygame.mixer

import GetString
import GetSound
import Voice

# xbeeとラズベリーパイのシリアル通信設定
PORT = '/dev/ttyUSB0'
BAUD_RATE = 9600
myDevice = serial.Serial(PORT, BAUD_RATE)
xbee = ZigBee(myDevice)

# ループ内で使用する変数の宣言
loop_flg = True
template_name = ''

# loop_flgがTrueの間以下の処理を継続する
while loop_flg:
    try:
        while True: #dio-1からdio-4でTrueを受信するまで処理を継続する
            response = xbee.wait_read_frame()
            samples = response['samples'][0]

            if samples['dio-1']:
                template_name = 'news_template'
                break

            elif samples['dio-2']:
                template_name = 'route_template'
                break

            elif samples['dio-3']:
                template_name = 'weather_template'
                break

            elif samples['dio-4']:
                template_name = 'plan_template'
                break

    except KeyboardInterrupt: #ctrl + C で強制終了した時の終了処理
        template_name = 'KeyboardInterrupt_error'
        print('keyboardInterrupt_error')
        loop_flg = False
        break    
    
    except: #原因不明のエラーで強制終了した時の終了処理
        template_name = 'unknown_error_template'
        print('unknown_error')
        loop_flg = False

    # 取得したキーでjsonから文字列を取得
    json = GetString.GetString(template_name)
    loop_flg = json.json_string()

    # 取得した文字列をpollyで音声へ変換
    polly = GetSound.GetSound(json.string)
    polly.polly_sound()

    # スピーカーから音声を出力
    Voice.Voice.play()
    
    time.sleep(0.1)
myDevice.close()
