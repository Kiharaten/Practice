#!/usr/bin/python3

import boto3

class GetSound:
    def __init__(self, string):
        '''
        このクラスで扱うインスタンスが持つ変数を定義する

        '''
        self.string = string

    def polly_sound(self):
        '''
        pollyへ文字列を送信し、返り値をsound.mp3として保存

        '''

        # pollyへ文字列と音声の設定を送信する
        polly = boto3.client("polly", region_name = "ap-northeast-1")
        response = polly.synthesize_speech(
            VoiceId = "Mizuki",
            OutputFormat = "mp3",
            Text = self.string
        )

        # 受け取った音声をsound.mp3として保存する
        with  open("sound.mp3", "wb") as file:
            file.write(response["AudioStream"].read())
