#!/usr/bin/python3

from mutagen.mp3 import MP3 as mp3
import pygame
import time

class Voice:
    def play():
        '''
        保存されている音声を再生する

        '''
        try:
            file_name = "sound.mp3"
            mp3_length = mp3(file_name).info.length

            #pygame.mixerの初期化・音声読み込み・再生・停止
            pygame.mixer.init()
            pygame.mixer.music.load(file_name)
            pygame.mixer.music.play(1)
            time.sleep(mp3_length + 0.25)
            pygame.mixer.music.stop()

        except pygame.error:
            pass
